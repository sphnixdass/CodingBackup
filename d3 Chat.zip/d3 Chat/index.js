
const svg= d3.select('svg');
svg.style('background-color','red');

const width = +svg.attr('width');
const height = +svg.attr('height');


var data = [
    {"name": "John", "age": 20, "city": "New York"},
    {"name": "Mike", "age": 30, "city": "London"},
    {"name": "Mary", "age": 40, "city": "Paris"},
    {"name": "Peter", "age": 50, "city": "Berlin"}
];

data.forEach(d => {
    d.age = +d.age + 1000;
});

const xValue = data => data.age;

const xScale = d3.scaleLinear()
.domain([0, d3.max(data, xValue)])
.range([0, width]);

const yScale = d3.scaleBand()
.domain(data.map(d => d.name))
.range([0, height])
.padding(0.2);

const yAxis = d3.axisLeft(yScale);

const g = svg.append('g')
.attr('transform',`translate(40,50)`);

g.append('g').call(d3.axisLeft(yScale))
.selectAll('.domain').remove();

g.append('g').call(d3.axisBottom(xScale))
.attr('transform',`translate(0,${height})`);


g.selectAll('rect').data(data)
.enter()
.append('rect')
.attr('y',d => yScale(d.name))
.attr('width',data => xScale(xValue(data)))
.attr('height',yScale.bandwidth())
.attr('fill','steelblue');

g.append('text')
.attr('y',20)
.attr('x',30)
.text("Dass");



console.log(data);
console.log(xScale(data[2].age));
